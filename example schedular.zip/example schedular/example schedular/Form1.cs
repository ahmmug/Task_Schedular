﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Xml.Serialization;
using System.IO;
using IWshRuntimeLibrary;
namespace example_schedular
{
    public partial class Task : MetroFramework.Forms.MetroForm 
    {
        OpenFileDialog od = new OpenFileDialog();
        string  dPicker="" ;
        string tPicker="" ;
        private bool NumericValueChanged = false;
      
        
        public Task()
        {
            InitializeComponent();

           
          
        }
        public class CustomerData
        {
            public string DP;
            public string TP;
            public string FP;

        }
        private void btnTrigger_Click(object sender, EventArgs e)
        {
            try
            {
                od = new OpenFileDialog();
                var _with = od;
                _with.Filter = "Applications(*.exe)|*.exe";
                if (od.ShowDialog() == DialogResult.OK)
                {
                    txtFile.Text = od.FileName;
                    dPicker = dateTimePicker1.Value.ToString("dd-MM-yyyy");
                    tPicker = dateTimePicker1.Value.ToString("HH:mm:ss");
                    timer1.Enabled = true;
                }
                CustomerData customer = new CustomerData();
                customer.DP = dPicker.ToString();
                customer.TP = tPicker.ToString();
                customer.FP = od.FileName;
                XmlSerializer xs = new XmlSerializer(typeof(CustomerData));
                using (FileStream fs = new FileStream("Data.xml", FileMode.Create))
                {
                    xs.Serialize(fs, customer);
                }
                //WshShell shell = new WshShell();
                //IWshShortcut startup;
                //startup = (IWshShortcut)shell.CreateShortcut(@"C:\Users\Ahmed Mughal\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\Uq1.lnk");
                //startup.TargetPath = Application.ExecutablePath;
                //startup.Description = "launch the app";
                //startup.Save();
                CreateStartupFolderShortcut();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
               
               
        }
        public void CreateStartupFolderShortcut()
        {
            WshShell wshShell = new WshShell();
            IWshRuntimeLibrary.IWshShortcut shortcut;
            string startUpFolderPath =
              Environment.GetFolderPath(Environment.SpecialFolder.Startup);

            // Create the shortcut
            shortcut =
              (IWshRuntimeLibrary.IWshShortcut)wshShell.CreateShortcut(
                startUpFolderPath + "\\" +
                Application.ProductName + ".lnk");

            shortcut.TargetPath = Application.ExecutablePath;
            shortcut.WorkingDirectory = Application.StartupPath;
            shortcut.Description = "Launch My Application";
            // shortcut.IconLocation = Application.StartupPath + @"\App.ico";
            shortcut.Save();
        }
        int timerCheck = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {                
                var  time = DateTime.Now.ToString("HH:mm:ss");
                var  date = DateTime.Today.ToString("dd-MM-yyyy");
                if (timerCheck == 0)
                {
                    if (date == dPicker)
                    {
                        if (time == tPicker)
                        {
                            System.Diagnostics.Process.Start(od.FileName);
                            timerCheck = 1;
                        }
                    }
                    if (NumericValueChanged)
                    {
                        for (int i = 0; i <= numericUpDown1.Value; i++)
                        {

                            if (time == tPicker)
                            {
                                System.Diagnostics.Process.Start(od.FileName);
                                timerCheck = 1;
                            }

                        }

                    }
                }
            if (timerCheck>=1 && timerCheck<=60)
            {
                timerCheck++;
            }
            else
            {
                timerCheck = 0;
            }
                
        }
      
        private void Form1_Load(object sender, EventArgs e)
        {
            timer2.Start();
            lblTime.Text = DateTime.Now.ToLongTimeString();

            if (System.IO.File.Exists("Data.xml"))
            {
                CustomerData customer;
                XmlSerializer xs = new XmlSerializer(typeof(CustomerData));
                using (FileStream fs = new FileStream("Data.xml", FileMode.Open))
                {
                   
                    customer = xs.Deserialize(fs) as CustomerData;
                }

              
                if (customer != null)
                {
                    dPicker = customer.DP;
                    tPicker = customer.TP;
                    od.FileName = customer.FP;
                    timer1.Enabled = true;
                }
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
          
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Start();
            lblTime.Text = DateTime.Now.ToLongTimeString();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            NumericValueChanged = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Hide();
            notifyIcon1.Visible = true;
           
          
            
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            notifyIcon1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
